document.addEventListener("DOMContentLoaded", function() {
    console.log("Site CIIJE carregado!");
});
